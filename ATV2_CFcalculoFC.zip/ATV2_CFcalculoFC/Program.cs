﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CFcalculoFC
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Qual temperatura deseja apresenta e converter?\n1 - Celsius\n2 - Fahrenheit");
            int opcao = int.Parse(Console.ReadLine());

            if (opcao == 1)
            {
                Console.WriteLine("Digite o número que deseja converter para fahrenheit:");
                float C = float.Parse(Console.ReadLine());

                float CF = ((9 * C) + 160) / 5;

                Console.WriteLine(C + "ºC em fahrenheit: " + CF + "ºF");
                Console.ReadLine();
            } else if(opcao == 2)
            {
                Console.WriteLine("Digite o número que deseja converter para celsius:");
                float F = float.Parse(Console.ReadLine());

                float FC = (F - 32) * (5 / 9);

                Console.WriteLine(F + "ºF em fahrenheit: " + FC + "ºC");
                Console.ReadLine();
            } else
            {
                Console.WriteLine("Undefined");
                Console.ReadLine();
            }
        }
    }
}
